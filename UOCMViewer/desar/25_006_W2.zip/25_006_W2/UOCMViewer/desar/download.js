var volum = new Array();
var volum_mb = new Array();
var zip = '';
var zip_mb = '';
var rar = '';
var rar_mb ='';
volum[0] = "codi_material.exe";

volum_mb[0] = "1,38 Mb.";

volum[1] = "codi_material.r00";

volum_mb[1] = "472	 KB";

zip='codi_material.zip'
zip_mb='2264	 Kb.'
rar='codi_material.exe'
rar_mb='2208	 Kb.'
